Steps
-----------------------------------------------------------------------------------------------------
1. copy the attached TransactionProcessing.jar in a folder
2. create below 3 folders in same folder where you kept the jar	
	-logs          (logs will be generated here, look for logs with ** appearing, easy to search)
	
	-pending       (place your input (.csv) file in this folder)
	-processed	   (once .csv file has been processed, it will be moved here)
	-reports	   (file_name.txt will be generated here. Please open this in Notepad++ or wordpad and not in simple notepad due to formatting)
	
	-properties    (place application.properties file here in this folder)


To run the Program
----------------------------------------------------------------------------------------------------
Place the jar and execute below command in same folder

java -jar TransactionProcessing.jar


Now, you can modify certain properties in application.properties
----------------------------------------------------------------
#Input directory
TRANSACTION_PROCESSING=F:\\MyData\\Interviews\\GreaterBank

#input fileName pattern
FILE_NAME_PATTERN=finance_customer_transactions-(.*).csv

#How many millis to wait after input file arrived
#run the job after 5 minutes;300000
WAIT_TIME_FILE_PROCESSING=2000

#When do you want to run the job
#In the problem you require to run at 
#once at 06:00 hours
#once at 21:00 hours
#so for this you need to edit below 2 CRON properties
#CRON_JOB_TIME_1=0 00 06 * * *
#CRON_JOB_TIME_2=0 00 21 * * *

#below jobs will run at 3:14PM and next at 3:15PM
CRON_JOB_TIME_1=0 14 15 * * *
CRON_JOB_TIME_2=0 15 15 * * *